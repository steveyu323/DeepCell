import sys, os
download_script_location = os.path.abspath(os.path.join('..','Utilities'))
if not download_script_location in sys.path:
    sys.path.append(download_script_location)

